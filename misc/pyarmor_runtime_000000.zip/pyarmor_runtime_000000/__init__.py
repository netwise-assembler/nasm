# Pyarmor 8.5.11 (trial), 000000, 2024-12-12T08:37:10.229714
from .pyarmor_runtime import __pyarmor__
